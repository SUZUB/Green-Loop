
# Submission Guidelines

1. Push your final code before the deadline.
2. Update the README with project details.
3. Include screenshots or demo video links.
4. Make sure your project runs correctly.
