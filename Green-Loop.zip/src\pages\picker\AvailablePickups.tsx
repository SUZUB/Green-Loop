import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { PageBackground } from "@/components/PageBackground";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAvailablePickups } from "@/hooks/useAvailablePickups";
import { usePickupSchedule } from "@/hooks/usePickupSchedule";
import { useToast } from "@/hooks/use-toast";
import { QRScannerModal } from "@/components/picker/QRScannerModal";
import { supabase } from "@/integrations/supabase/client";
import {
  MapPin, Weight, RefreshCw, Navigation, Loader2, Package, ScanLine,
  CalendarDays, Clock, Coins,
} from "lucide-react";

const timeSlotLabels: Record<string, string> = {
  morning: "Morning · 8 AM–12 PM",
  afternoon: "Afternoon · 12–5 PM",
  evening: "Evening · 5–8 PM",
};

function openMaps(lat: number, lng: number) {
  window.open(
    `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`,
    "_blank",
    "noopener,noreferrer"
  );
}

export default function AvailablePickups() {
  const [scannerOpen, setScannerOpen] = useState(false);
  const [acceptedId, setAcceptedId] = useState<string | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserName, setCurrentUserName] = useState("Picker");
  const { toast } = useToast();

  // Supabase-backed live feed
  const { pickups: liveFeed, loading, accepting, error, accept, refresh } = useAvailablePickups();

  // Local schedule store (works offline too)
  const { scheduledForPickers, acceptPickup, completePickup } = usePickupSchedule();

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) return;
      setCurrentUserId(user.id);
      const { data } = await supabase.from("profiles").select("full_name").eq("id", user.id).maybeSingle();
      setCurrentUserName((data as any)?.full_name ?? "Picker");
    });
  }, []);

  // Merge: schedule store items not already in live feed
  const scheduledIds = new Set(liveFeed.map((p) => p.id));
  const offlineScheduled = scheduledForPickers.filter((p) => !scheduledIds.has(p.id));

  const handleAccept = async (id: string, address: string) => {
    // Try Supabase first
    const ok = await accept(id);
    // Also update local schedule store
    if (currentUserId) acceptPickup(id, currentUserId, currentUserName);

    if (ok || currentUserId) {
      setAcceptedId(id);
      toast({
        title: "Pickup accepted!",
        description: `Navigate to ${address}, collect the items, then scan the recycler's QR to confirm and earn credits.`,
      });
    } else {
      toast({
        title: "Could not accept pickup",
        description: error ?? "It may have been taken by another picker.",
        variant: "destructive",
      });
    }
  };

  const handleOfflineAccept = (id: string, address: string) => {
    if (!currentUserId) return;
    acceptPickup(id, currentUserId, currentUserName);
    setAcceptedId(id);
    toast({
      title: "Pickup accepted!",
      description: `Navigate to ${address}, collect the items, then scan the recycler's QR to confirm and earn credits.`,
    });
  };

  return (
    <div className="min-h-screen">
      <PageBackground type="recycling" overlay="bg-[#F8FAF9]/65" />

      <div className="container mx-auto px-4 py-6 max-w-lg">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-display font-bold">Pickup Schedule</h1>
            <p className="text-sm text-[#475569] mt-0.5">Live feed — updates in real-time</p>
          </div>
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading} className="gap-1.5">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        {loading && liveFeed.length === 0 && offlineScheduled.length === 0 ? (
          <div className="flex justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-[#14532D]" />
          </div>
        ) : liveFeed.length === 0 && offlineScheduled.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Package className="h-12 w-12 text-[#475569] mb-4 opacity-40" />
            <p className="font-semibold text-[#475569]">No pickups available right now</p>
            <p className="text-sm text-[#475569] mt-1">New requests appear here instantly when recyclers post them.</p>
          </div>
        ) : (
          <AnimatePresence initial={false}>
            <div className="space-y-3">
              {/* Live Supabase feed */}
              {liveFeed.map((pickup, i) => (
                <motion.div
                  key={pickup.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.3, delay: i * 0.04 }}
                >
                  <Card className="p-4 border border-[#D1FAE5] hover:shadow-soft transition-shadow">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{pickup.recycler_name}</p>
                        <p className="text-xs text-[#475569] flex items-center gap-1 mt-0.5">
                          <MapPin className="h-3 w-3 shrink-0" />
                          <span className="truncate">{pickup.address || `${pickup.lat.toFixed(4)}, ${pickup.lng.toFixed(4)}`}</span>
                        </p>
                      </div>
                      <Badge className="bg-emerald/10 text-emerald border-0 shrink-0">AVAILABLE</Badge>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-[#475569] mb-2">
                      <span className="flex items-center gap-1">
                        <Weight className="h-3.5 w-3.5" /> {pickup.weight_kg} kg
                      </span>
                      <span className="flex items-center gap-1 text-[#14532D] font-semibold">
                        <Coins className="h-3.5 w-3.5" /> ~{Math.round(pickup.weight_kg * 100)} credits
                      </span>
                    </div>

                    {pickup.notes && (
                      <p className="text-xs text-[#475569] bg-white/50 rounded-lg px-3 py-2 mb-3">
                        {pickup.notes}
                      </p>
                    )}

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="flex-1"
                        disabled={accepting === pickup.id}
                        onClick={() => handleAccept(pickup.id, pickup.address)}
                      >
                        {accepting === pickup.id
                          ? <Loader2 className="h-4 w-4 animate-spin" />
                          : "Accept Pickup"}
                      </Button>
                      <Button size="sm" variant="outline" className="gap-1.5" onClick={() => openMaps(pickup.lat, pickup.lng)}>
                        <Navigation className="h-4 w-4" />
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}

              {/* Offline / local schedule store */}
              {offlineScheduled.map((pickup, i) => (
                <motion.div
                  key={pickup.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.3, delay: (liveFeed.length + i) * 0.04 }}
                >
                  <Card className="p-4 border border-[#D1FAE5] hover:shadow-soft transition-shadow">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{pickup.recycler_name}</p>
                        <p className="text-xs text-[#475569] flex items-center gap-1 mt-0.5">
                          <MapPin className="h-3 w-3 shrink-0" />
                          <span className="truncate">{pickup.address}</span>
                        </p>
                      </div>
                      <Badge
                        className={
                          pickup.status === "assigned"
                            ? "bg-[#f6ad55]/10 text-[#14532D] border-0 shrink-0"
                            : "bg-[#10B981]/10 text-[#14532D] border-0 shrink-0"
                        }
                      >
                        {pickup.status === "assigned" ? "ASSIGNED" : "SCHEDULED"}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5 text-xs text-[#475569] mb-3">
                      <span className="flex items-center gap-1">
                        <CalendarDays className="h-3 w-3" /> {pickup.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {timeSlotLabels[pickup.time_slot] ?? pickup.time_slot}
                      </span>
                      <span className="flex items-center gap-1">
                        <Weight className="h-3 w-3" /> {pickup.weight_kg} kg
                      </span>
                      <span className="flex items-center gap-1 text-[#14532D] font-semibold">
                        <Coins className="h-3 w-3" /> ~{Math.round(pickup.weight_kg * 100)} credits
                      </span>
                    </div>

                    {pickup.status === "scheduled" && (
                      <Button
                        size="sm"
                        className="w-full"
                        onClick={() => handleOfflineAccept(pickup.id, pickup.address)}
                      >
                        Accept Pickup
                      </Button>
                    )}
                    {pickup.status === "assigned" && pickup.picker_id === currentUserId && (
                      <Button
                        size="sm"
                        variant="secondary"
                        className="w-full gap-2"
                        onClick={() => setScannerOpen(true)}
                      >
                        <ScanLine className="h-4 w-4" /> Scan QR to Complete
                      </Button>
                    )}
                  </Card>
                </motion.div>
              ))}
            </div>
          </AnimatePresence>
        )}
      </div>

      {/* Sticky scan banner — shown after picker accepts a pickup */}
      <AnimatePresence>
        {acceptedId && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            className="fixed bottom-0 left-0 right-0 z-50 p-4 bg-[#10B981] shadow-elevated"
          >
            <div className="container mx-auto max-w-lg flex items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-white text-sm">Pickup accepted</p>
                <p className="text-white/80 text-xs">
                  Arrive at the recycler, collect items, then scan their QR to confirm and earn credits.
                </p>
              </div>
              <Button size="sm" variant="secondary" className="gap-2 shrink-0" onClick={() => setScannerOpen(true)}>
                <ScanLine className="h-4 w-4" /> Scan QR
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <QRScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onSuccess={(result) => {
          // Mark the accepted pickup as completed in the schedule store
          if (acceptedId) completePickup(acceptedId, result.weight_kg);
          setAcceptedId(null);
          toast({
            title: "Pickup complete ✓",
            description: `${result.weight_kg} kg collected. ${result.points} credits added to your wallet.`,
          });
        }}
      />
    </div>
  );
}
