import { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import { PageBackground } from "@/components/PageBackground";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { QRCodeDisplay } from "@/components/recycler/QRCodeDisplay";
import { usePickupSchedule, ScheduledPickup } from "@/hooks/usePickupSchedule";
import {
  User, Mail, Star, CalendarDays, Weight,
  Download, Search, CheckCircle2, XCircle, Loader2, Coins, MapPin, Clock,
} from "lucide-react";

interface ProfileRow {
  id: string;
  full_name: string;
  role: string;
  coin_balance: number;
  total_pickups: number;
  total_recycled_kg: number;
  total_points: number;
}

const timeSlotLabels: Record<string, string> = {
  morning: "Morning · 8 AM–12 PM",
  afternoon: "Afternoon · 12–5 PM",
  evening: "Evening · 5–8 PM",
};

const RecyclerProfile = () => {
  const { toast } = useToast();
  const { recyclerHistory } = usePickupSchedule();
  const [tab, setTab] = useState("history");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<ProfileRow | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [search, setSearch] = useState("");
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackText, setFeedbackText] = useState("");

  // Editable settings fields
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editAddress, setEditAddress] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      const { data: auth } = await supabase.auth.getUser();
      const user = auth.user;
      if (!user) { setLoading(false); return; }

      setEmail(user.email ?? "");
      setUserId(user.id);

      const { data: profileRow } = await supabase
        .from("profiles").select("*").eq("id", user.id).maybeSingle();

      if (!cancelled) {
        const p = profileRow as ProfileRow | null;
        setProfile(p);
        setEditName(p?.full_name ?? "");
        setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  // All pickups for this recycler from the shared schedule (localStorage + realtime)
  const allPickups: ScheduledPickup[] = userId ? recyclerHistory(userId) : [];
  const completedPickups = allPickups.filter((p) => p.status === "completed");
  const activePickups    = allPickups.filter((p) => p.status !== "completed");

  const filtered = completedPickups.filter(
    (p) =>
      p.id.toLowerCase().includes(search.toLowerCase()) ||
      p.address.toLowerCase().includes(search.toLowerCase())
  );

  const handleExport = useCallback(() => {
    const csv =
      "ID,Date,Address,Weight(kg),Credits,Status\n" +
      completedPickups
        .map((p) => `${p.id},${p.date},${p.address},${p.weight_kg},${p.credits},${p.status}`)
        .join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "pickup-history.csv"; a.click();
    URL.revokeObjectURL(url);
  }, [completedPickups]);

  // Called by QRCodeDisplay when the picker completes the scan
  const handlePickupCompleted = useCallback(() => {
    setTab("history");
    toast({
      title: "Pickup completed! 🎉",
      description: "Your credits have been added. Check your history below.",
    });
  }, [toast]);

  const handleSaveSettings = async () => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles")
      .update({ full_name: editName })
      .eq("id", auth.user.id);
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      setProfile((prev) => prev ? { ...prev, full_name: editName } : prev);
      toast({ title: "Profile saved! ✅" });
    }
  };

  const initials = (profile?.full_name ?? "?")
    .split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#14532D]" />
      </div>
    );
  }

  // Derive live stats from schedule (more up-to-date than Supabase profile row)
  const liveKg      = completedPickups.reduce((s, p) => s + Number(p.weight_kg), 0);
  const liveCredits = completedPickups.reduce((s, p) => s + Number(p.credits), 0);

  return (
    <div className="min-h-screen">
      <PageBackground type="waste" overlay="bg-[#F8FAF9]/65" />
      <div className="container mx-auto px-4 py-6 max-w-lg">

        {/* Profile card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-6 mb-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-full bg-hero-gradient flex items-center justify-center text-white font-display font-bold text-xl">
                {initials || <User className="h-7 w-7" />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-display font-bold text-lg">{profile?.full_name || "Recycler"}</h2>
                  <Badge className="text-[10px] bg-[#10B981]">Verified ✓</Badge>
                </div>
                <p className="text-xs text-[#475569] flex items-center gap-1">
                  <Mail className="h-3 w-3" /> {email}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-2 rounded-lg bg-muted">
                <div className="font-display font-bold">{liveKg.toFixed(1)} kg</div>
                <p className="text-[10px] text-[#475569]">Recycled</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-muted">
                <div className="font-display font-bold">{liveCredits}</div>
                <p className="text-[10px] text-[#475569]">Credits</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-muted">
                <div className="font-display font-bold">{completedPickups.length}</div>
                <p className="text-[10px] text-[#475569]">Pickups</p>
              </div>
            </div>
          </Card>
        </motion.div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="w-full mb-4">
            <TabsTrigger value="history" className="flex-1">History</TabsTrigger>
            <TabsTrigger value="qr" className="flex-1">QR Code</TabsTrigger>
            <TabsTrigger value="feedback" className="flex-1">Feedback</TabsTrigger>
            <TabsTrigger value="settings" className="flex-1">Settings</TabsTrigger>
          </TabsList>

          {/* ── History ── */}
          <TabsContent value="history">
            {/* Active pickups pinned at top */}
            {activePickups.map((p) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-3"
              >
                <Card className={`p-4 border-l-4 ${p.status === "assigned" ? "border-l-amber-500" : "border-l-emerald-500"}`}>
                  <div className="flex items-center justify-between mb-2">
                    <Badge className={`text-xs ${p.status === "assigned" ? "bg-[#DCFCE7] text-[#14532D]" : "bg-emerald-100 text-[#14532D]"}`}>
                      {p.status === "assigned" ? "🚴 Picker Assigned" : "📅 Scheduled"}
                    </Badge>
                    <span className="text-xs font-mono text-[#475569]">{p.id.slice(0, 10)}…</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-xs text-[#475569]">
                    <span className="flex items-center gap-1"><Weight className="h-3 w-3" /> {Number(p.weight_kg).toFixed(1)} kg</span>
                    <span className="flex items-center gap-1"><CalendarDays className="h-3 w-3" /> {p.date}</span>
                    <span className="flex items-center gap-1 col-span-2 truncate"><MapPin className="h-3 w-3" /> {p.address}</span>
                    {p.time_slot && <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {timeSlotLabels[p.time_slot] ?? p.time_slot}</span>}
                  </div>
                </Card>
              </motion.div>
            ))}

            {/* Completed history */}
            <div className="flex gap-2 mb-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#475569]" />
                <Input
                  placeholder="Search by ID or address…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Button variant="outline" size="sm" onClick={handleExport} className="gap-1" disabled={completedPickups.length === 0}>
                <Download className="h-4 w-4" /> CSV
              </Button>
            </div>

            {allPickups.length === 0 ? (
              <p className="text-center text-[#475569] py-10 text-sm">
                No pickups yet. Book your first pickup to get started!
              </p>
            ) : filtered.length === 0 && completedPickups.length > 0 ? (
              <p className="text-center text-[#475569] py-6 text-sm">No results match your search.</p>
            ) : (
              <div className="space-y-2">
                {filtered.map((p, i) => (
                  <motion.div key={p.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}>
                    <Card className="p-3 border-[#D1FAE5]">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-mono text-[#475569]">{p.id.slice(0, 12)}…</span>
                        <Badge variant="outline" className="text-[10px] border-[#D1FAE5] text-[#14532D] bg-[#10B981]/10">
                          <CheckCircle2 className="h-3 w-3 mr-1" /> Completed
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3 text-[#475569] text-xs">
                          <span className="flex items-center gap-1">
                            <CalendarDays className="h-3 w-3" /> {p.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <Weight className="h-3 w-3" /> {Number(p.weight_kg).toFixed(1)} kg
                          </span>
                        </div>
                        <span className="font-display font-bold text-[#14532D] flex items-center gap-1">
                          <Coins className="h-3.5 w-3.5" /> +{Number(p.credits)}
                        </span>
                      </div>
                      {p.picker_name && (
                        <p className="text-xs text-[#475569] mt-1">Picker: {p.picker_name}</p>
                      )}
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* ── QR Code ── */}
          <TabsContent value="qr">
            <div className="space-y-3">
              <div className="bg-[#10B981] rounded-2xl p-4 text-[#1E293B]">
                <p className="text-xs font-bold uppercase tracking-widest text-[#1E293B]/70 mb-1">My Unique QR</p>
                <p className="text-sm text-[#1E293B]/90">
                  Show this to the picker when they arrive. Once they scan and confirm the weight, you'll be moved to History automatically.
                </p>
              </div>
              <QRCodeDisplay onPickupCompleted={handlePickupCompleted} />
            </div>
          </TabsContent>

          {/* ── Feedback ── */}
          <TabsContent value="feedback">
            <Card className="p-5 space-y-4">
              <div>
                <Label>Rate your experience</Label>
                <div className="flex gap-1 mt-2">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button key={s} onClick={() => setFeedbackRating(s)}>
                      <Star className={`h-8 w-8 ${s <= feedbackRating ? "fill-[#6fcf97] text-[#065F46]" : "text-muted"}`} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <Label>Comments or suggestions</Label>
                <textarea
                  className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  placeholder="Tell us how we can improve..."
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={() => {
                toast({ title: "Thank you for your feedback! 💚" });
                setFeedbackRating(0); setFeedbackText("");
              }}>Submit Feedback</Button>
            </Card>
          </TabsContent>

          {/* ── Settings ── */}
          <TabsContent value="settings">
            <Card className="p-5 space-y-4">
              <div>
                <Label>Full Name</Label>
                <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Email</Label>
                <Input value={email} disabled className="mt-1 opacity-60" />
                <p className="text-xs text-[#475569] mt-1">Email cannot be changed here.</p>
              </div>
              <div>
                <Label>Phone</Label>
                <Input value={editPhone} onChange={(e) => setEditPhone(e.target.value)} placeholder="Enter phone number" className="mt-1" />
              </div>
              <div>
                <Label>Address</Label>
                <Input value={editAddress} onChange={(e) => setEditAddress(e.target.value)} placeholder="Enter your address" className="mt-1" />
              </div>
              <Button className="w-full" onClick={handleSaveSettings} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Save Changes
              </Button>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default RecyclerProfile;
